$(document).ready(function(){
  var sp = 0;
  var x;
  var y;
  $( document ).on( "mousemove", function( event ) {
  x = event.pageX;
  y = event.pageY;
  console.log(sp)
  if ((x <= 823) && (y <= 385) && (sp == 0))
  {
    $("#preview").css("position", "absolute").css("left", x+50).css("top", y-50);
  }
  else if ((x > 823) && (y <= 386) && (sp == 0))
  {
    $("#preview").css("position", "absolute").css("left", x-690).css("top", y-50);
  }
  else if ((x > 823) && (y > 385) && (sp == 0))
  {
    $("#preview").css("position", "absolute").css("left", x-690).css("top", y-250);
  }
  else if ((x <= 823) && (y > 385) && (sp == 0))
  {
    $("#preview").css("position", "absolute").css("left", x+50).css("top", y-250);
  }
  else if ((x <= 823) && (sp == 24))
  {
    $("#preview").css("position", "absolute").css("left", x+50).css("top", y-400);
  }
  else if ((x <= 823) && (sp == 22))
  {
    $("#preview").css("position", "absolute").css("left", x+50).css("top", y-230);
  }
  else if ((x > 823) && (sp == 101))
  {
    $("#preview").css("position", "absolute").css("left", x-550).css("top", y-400);
  }
  else if ((x > 823) && (sp == 102))
  {
    $("#preview").css("position", "absolute").css("left", x-690).css("top", y-465);
  }
});
  for (var i=0; i < images.length; i++)
    {
     $(".gallery").append("<li><img src=\"images/square/" + images[i].path + "\" alt=\"" + images[i].title + "\" ></li>");

    }
  $(".gallery li img").on("mouseenter", function (e){
    $(this).attr("class", "gray");
    for (var i=0; i < images.length; i++)
    {
      if (images[i].title == e.target.alt)
      {
        var src = images[i].path
        var city = images[i].city
        var country = images[i].country
        var date = images[i].taken
        if (images[i].id == 24)
        {
          sp = 24;
        }
        else if  (images[i].id == 101)
        {
          sp = 101;
        }
        else if  (images[i].id == 22)
        {
          sp = 22;
        }
        else if (images[i].id == 102)
        {
          sp = 102;
        }
        else
        {
          sp = 0;
        }
      }
    }
    $("body").append("<div id=\"preview\"> <img src=\"images/medium/" + src + "\" ><p>" + e.target.alt + "<br>" + country + ", " + city +"[" + date + "]");
    $("#preview").fadeIn(1000)

  });
  $(".gallery li img").on("mouseleave", function (e){
    $(this).attr("class", "");
    $("#preview").remove();
  });

});
