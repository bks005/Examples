var countries = [
    {
        id:  "DE",
        name: "Germany"
    },
    {
        id:  "GR",
        name: "Greece"
    },
    {
        id:  "IT",
        name: "Italy"
    },
    {
        id:  "CA",
        name: "Canada"
    },
    {
        id:  "GB",
        name: "United Kingdom"
    },
    {
        id:  "US",
        name: "United States"
    },    
    
];
    